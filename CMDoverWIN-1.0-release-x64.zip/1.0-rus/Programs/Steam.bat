start "" "C:\Games\Steam\steam.exe"
start "" "C:\Games\Hydra\Hydra.exe"
cls
dir