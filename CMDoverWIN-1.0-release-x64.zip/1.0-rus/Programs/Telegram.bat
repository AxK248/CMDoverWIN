start "" "C:\Games\Telegram\Telegram.exe"
start "" "C:\Games\Telegram\TgWsProxy_windows.exe"
cls
dir