@echo off
:menu
chcp 65001
title Volume Settings
cls
echo ===============
echo Звук:
echo -
echo [1] Уровень 6
echo [2] Уровень 8
echo [3] Уровень 12
echo [4] Уровень 22
echo [5] Выключить/включить звук
echo [6] Выход
echo -
echo ===============
set "password="
set /p password="Введите код: "

if /i "%password%"=="1" "%~dp0nircmdc.exe" setsysvolume 3932 & goto exit
if /i "%password%"=="2" "%~dp0nircmdc.exe" setsysvolume 5243 & goto exit
if /i "%password%"=="3" "%~dp0nircmdc.exe" setsysvolume 7864 & goto exit
if /i "%password%"=="4" "%~dp0nircmdc.exe" setsysvolume 14418 & goto exit
if /i "%password%"=="5" "%~dp0nircmdc.exe" mutesysvolume 2 & goto exit
if /i "%password%"=="6" goto exit

color c
cls
echo [ERROR]
timeout /t 1 /nobreak >nul
color f
cls
echo [-----]
echo Извините ваш код неверный!
echo Идёт сброс страницы
timeout /t 3 /nobreak >nul
goto menu

:exit
"%~dp0dirboot\cmd.bat"