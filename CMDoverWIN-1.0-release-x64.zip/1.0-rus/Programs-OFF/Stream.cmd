@echo off
taskkill /f /im "Stream Overlay.exe"
@echo on
cls
dir