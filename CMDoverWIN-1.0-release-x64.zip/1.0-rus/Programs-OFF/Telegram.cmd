@echo off
taskkill /f /im Telegram.exe
taskkill /f /im TgWsProxy_windows.exe
@echo on
cls
dir