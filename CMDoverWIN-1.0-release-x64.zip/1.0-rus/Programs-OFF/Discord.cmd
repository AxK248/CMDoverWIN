@echo off
taskkill /f /im discord.exe
@echo on
cls
dir