@echo off
taskkill /f /im Steam.exe
taskkill /f /im Hydra.exe
@echo on
cls
dir