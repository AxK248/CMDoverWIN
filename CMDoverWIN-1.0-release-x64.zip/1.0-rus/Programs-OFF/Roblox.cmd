@echo off
taskkill /f /im RobloxPlayerBeta.exe
@echo on
cls
dir