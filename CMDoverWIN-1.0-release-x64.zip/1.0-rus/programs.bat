@echo off
cd /d %~dp0\Programs
cls
dir
@echo on