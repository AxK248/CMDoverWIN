@echo off
cd /d %~dp0\Programs-OFF
cls
dir
@echo on